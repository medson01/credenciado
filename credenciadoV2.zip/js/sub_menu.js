jQuery(document).on('click', '.mega-dropdown', function(e) {
  e.stopPropagation()
})